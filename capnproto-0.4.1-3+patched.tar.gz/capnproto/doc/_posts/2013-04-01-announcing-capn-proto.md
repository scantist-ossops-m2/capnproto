---
layout: post
title: Announcing Cap'n Proto
author: kentonv
---

<img src='{{ site.baseurl }}images/infinity-times-faster.png' style='width:334px; height:306px; float: right;'>

So, uh...  I have a confession to make.

I may have rewritten Protocol Buffers.

Again.

[And it's infinity times faster.](http://kentonv.github.com/capnproto)
